import 'package:flame/game.dart';

class GameTemp extends FlameGame {}
