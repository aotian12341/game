import 'dart:math';
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flame/flame.dart';
import 'package:flame/parallax.dart';
import 'package:flutter/cupertino.dart';
import 'package:plane/game/game_controller.dart';
import 'package:plane/game/image_assets.dart';

import 'game_config.dart';
import 'game_view.dart';

class GameBg extends ParallaxComponent<GameView> {
  List<ParallaxLayer> layouts = [];

  int bgIndex = 0;

  Function onBack;

  GameBg({required this.onBack});

  @override
  Future<void> onLoad() async {
    var index = Random().nextInt(PlaneImages.bg.length);

    final bg = await Flame.images.load(PlaneImages.bg[index]);

    size = game.size;

    for (final image in PlaneImages.bg) {
      layouts.add(ParallaxLayer(ParallaxImage(await Flame.images.load(image),
          repeat: ImageRepeat.repeatY, fill: LayerFill.width)));
    }

    // 目前是可以的
    parallax = Parallax([
      ParallaxLayer(
          ParallaxImage(bg, repeat: ImageRepeat.repeatY, fill: LayerFill.width))
    ]);

    priority = 0;
  }

  @override
  void update(double dt) {
    // TODO: implement update
    super.update(dt);
    // print(parallax?.currentOffset());
    if (GameController().isRunning) {
      parallax?.baseVelocity.y = GameConfig.bgMoveSpeed;
    } else {
      parallax?.baseVelocity.y = 0;
    }
    if ((parallax?.currentOffset().y ?? 0) >= 0.999) {
      onBack();
      // parallax?.layers.removeAt(layouts.length - 1);
      // bgIndex += 1;
      // if (bgIndex == layouts.length - 1) {
      //   bgIndex = 0;
      // }
      // parallax?.layers.add(layouts[bgIndex]);
    }
  }
}
