class GameServer {
  factory GameServer() => _getInstance();

  // 静态私有成员，没有初始化
  static GameServer? _instance;

  // 静态、同步、私有访问点
  static GameServer _getInstance() {
    _instance ??= GameServer._internal();
    return _instance!;
  }

  // 私有构造函数
  GameServer._internal();
}
